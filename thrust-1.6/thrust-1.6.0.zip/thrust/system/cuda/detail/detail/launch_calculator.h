/*
 *  Copyright 2008-2012 NVIDIA Corporation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

#pragma once

#include <thrust/detail/config.h>

#include <thrust/system/cuda/detail/arch.h>
#include <thrust/tuple.h>

namespace thrust
{
namespace system
{
namespace cuda
{
namespace detail
{
namespace detail
{

template <typename Closure>
class launch_calculator
{
  arch::device_properties_t   properties;
  arch::function_attributes_t attributes;

  public:
  
  launch_calculator(void);

  launch_calculator(const arch::device_properties_t& properties, const arch::function_attributes_t& attributes);

  thrust::tuple<size_t,size_t,size_t> with_variable_block_size(void);

  template <typename UnaryFunction>
  thrust::tuple<size_t,size_t,size_t> with_variable_block_size(UnaryFunction block_size_to_smem_size);
  
  thrust::tuple<size_t,size_t,size_t> with_variable_block_size_available_smem(void);
};

} // end namespace detail
} // end namespace detail
} // end namespace cuda
} // end namespace system
} // end namespace thrust

#include <thrust/system/cuda/detail/detail/launch_calculator.inl>

